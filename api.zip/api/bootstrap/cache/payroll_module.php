<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Payroll\\App\\Providers\\PayrollServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Payroll\\App\\Providers\\PayrollServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);