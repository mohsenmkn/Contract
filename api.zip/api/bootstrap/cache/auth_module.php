<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Auth\\App\\Providers\\AuthServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Auth\\App\\Providers\\AuthServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);