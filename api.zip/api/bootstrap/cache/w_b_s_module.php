<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\WBS\\App\\Providers\\WBSServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\WBS\\App\\Providers\\WBSServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);