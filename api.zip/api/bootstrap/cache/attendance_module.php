<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Attendance\\App\\Providers\\AttendanceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Attendance\\App\\Providers\\AttendanceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);