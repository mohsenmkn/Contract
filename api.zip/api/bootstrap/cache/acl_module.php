<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Acl\\App\\Providers\\AclServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Acl\\App\\Providers\\AclServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);