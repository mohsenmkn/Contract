<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Dashboard\\App\\Providers\\DashboardServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Dashboard\\App\\Providers\\DashboardServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);