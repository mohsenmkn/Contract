<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Invoice\\App\\Providers\\InvoiceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Invoice\\App\\Providers\\InvoiceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);