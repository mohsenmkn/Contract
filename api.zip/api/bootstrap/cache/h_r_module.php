<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\HR\\App\\Providers\\HRServiceProvider',
    1 => 'Modules\\HR\\App\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\HR\\App\\Providers\\HRServiceProvider',
    1 => 'Modules\\HR\\App\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);