<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Contract\\App\\Providers\\ContractServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Contract\\App\\Providers\\ContractServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);