<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\WarehouseGtrabar\\App\\Providers\\WarehouseGtrabarServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\WarehouseGtrabar\\App\\Providers\\WarehouseGtrabarServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);