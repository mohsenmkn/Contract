<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Organization\\App\\Providers\\OrganizationServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Organization\\App\\Providers\\OrganizationServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);