<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Alert\\App\\Providers\\AlertServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Alert\\App\\Providers\\AlertServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);