<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Signature\\App\\Providers\\SignatureServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Signature\\App\\Providers\\SignatureServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);