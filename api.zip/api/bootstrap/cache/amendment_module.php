<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Amendment\\App\\Providers\\AmendmentServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Amendment\\App\\Providers\\AmendmentServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);