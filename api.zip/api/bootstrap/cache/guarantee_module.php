<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Guarantee\\App\\Providers\\GuaranteeServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Guarantee\\App\\Providers\\GuaranteeServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);