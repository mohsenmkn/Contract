<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Warehouse\\App\\Providers\\WarehouseServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Warehouse\\App\\Providers\\WarehouseServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);