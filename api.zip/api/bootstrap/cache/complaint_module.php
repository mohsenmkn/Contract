<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Complaint\\App\\Providers\\ComplaintServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Complaint\\App\\Providers\\ComplaintServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);