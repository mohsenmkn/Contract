<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Document\\App\\Providers\\DocumentServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Document\\App\\Providers\\DocumentServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);