<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Finance\\App\\Providers\\FinanceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Finance\\App\\Providers\\FinanceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);