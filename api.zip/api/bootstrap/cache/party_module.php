<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Party\\App\\Providers\\PartyServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Party\\App\\Providers\\PartyServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);