<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\SystemSettings\\App\\Providers\\SystemSettingsServiceProvider',
    1 => 'Modules\\SystemSettings\\App\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\SystemSettings\\App\\Providers\\SystemSettingsServiceProvider',
    1 => 'Modules\\SystemSettings\\App\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);