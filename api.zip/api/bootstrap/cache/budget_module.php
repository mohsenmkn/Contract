<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Budget\\App\\Providers\\BudgetServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Budget\\App\\Providers\\BudgetServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);