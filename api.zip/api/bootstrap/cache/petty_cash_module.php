<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\PettyCash\\App\\Providers\\PettyCashServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\PettyCash\\App\\Providers\\PettyCashServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);