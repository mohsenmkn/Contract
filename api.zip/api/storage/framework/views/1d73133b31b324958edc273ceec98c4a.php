<?php echo e($slot); ?>

<?php /**PATH E:\laragon\Contr\api\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>