<?php

use Illuminate\Support\Str;

return [

    /*
    |--------------------------------------------------------------------------
    | Default Database Connection Name
    |--------------------------------------------------------------------------
    |
    | Here you may specify which of the database connections below you wish
    | to use as your default connection for all database work. Of course
    | you may use many connections at once using the Database library.
    |
    */

    'default' => env('DB_CONNECTION', 'mysql'),

    /*
    |--------------------------------------------------------------------------
    | Database Connections
    |--------------------------------------------------------------------------
    |
    | Here are each of the database connections setup for your application.
    | Of course, examples of configuring each database platform that is
    | supported by Laravel is shown below to make development simple.
    |
    |
    | All database work in Laravel is done through the PHP PDO facilities
    | so make sure you have the driver for your particular database of
    | choice installed on your machine before you begin development.
    |
    */

    'connections' => [

        'sqlite' => [
            'driver' => 'sqlite',
            'url' => env('DATABASE_URL'),
            'database' => env('DB_DATABASE', database_path('database.sqlite')),
            'prefix' => '',
            'foreign_key_constraints' => env('DB_FOREIGN_KEYS', true),
        ],

        'mysql' => [
            'driver' => 'mysql',
            'url' => env('DATABASE_URL'),
            'host' => env('DB_HOST', '127.0.0.1'),
            'port' => env('DB_PORT', '3306'),
            'database' => env('DB_DATABASE', 'forge'),
            'username' => env('DB_USERNAME', 'forge'),
            'password' => env('DB_PASSWORD', ''),
            'unix_socket' => env('DB_SOCKET', ''),
            'charset' => 'utf8mb4',
            'collation' => 'utf8mb4_unicode_ci',
            'prefix' => '',
            'prefix_indexes' => true,
            'strict' => true,
            'engine' => null,
            'options' => extension_loaded('pdo_mysql') ? array_filter([
                PDO::MYSQL_ATTR_SSL_CA => env('MYSQL_ATTR_SSL_CA'),
            ]) : [],
        ],

        'pgsql' => [
            'driver' => 'pgsql',
            'url' => env('DATABASE_URL'),
            'host' => env('DB_HOST', '127.0.0.1'),
            'port' => env('DB_PORT', '5432'),
            'database' => env('DB_DATABASE', 'forge'),
            'username' => env('DB_USERNAME', 'forge'),
            'password' => env('DB_PASSWORD', ''),
            'charset' => 'utf8',
            'prefix' => '',
            'prefix_indexes' => true,
            'search_path' => 'public',
            'sslmode' => 'prefer',
        ],

        'sqlsrv' => [
            'driver' => 'sqlsrv',
            'url' => env('DATABASE_URL'),
            'host' => env('DB_HOST', 'localhost'),
            'port' => env('DB_PORT', '1433'),
            'database' => env('DB_DATABASE', 'forge'),
            'username' => env('DB_USERNAME', 'forge'),
            'password' => env('DB_PASSWORD', ''),
            'charset' => 'utf8',
            'prefix' => '',
            'prefix_indexes' => true,
            // 'encrypt' => env('DB_ENCRYPT', 'yes'),
            // 'trust_server_certificate' => env('DB_TRUST_SERVER_CERTIFICATE', 'false'),
        ],

        'gtarabar' => [
            'driver'   => 'sqlsrv',
            'host'     => env('GTARABAR_HOST', '127.0.0.1'),
            'port'     => env('GTARABAR_PORT', '1433'),
            'database' => env('GTARABAR_DATABASE', 'Gtarabar'),
            'username' => env('GTARABAR_USERNAME', 'Karimi_read'),
            'password' => env('GTARABAR_PASSWORD', ''),
            'charset'  => 'utf8',
            'prefix'   => '',
            'collation' => 'Persian_100_CI_AI_SC',
            ... (filter_var(env('GTARABAR_ENCRYPT', false), FILTER_VALIDATE_BOOLEAN) ? [
                'encrypt' => 'yes',
                'trust_server_certificate' => filter_var(env('GTARABAR_TRUST_SERVER_CERTIFICATE', true), FILTER_VALIDATE_BOOLEAN),
            ] : []),
            'options'  => [
                PDO::SQLSRV_ATTR_QUERY_TIMEOUT => 30,
                PDO::SQLSRV_ATTR_ENCODING => PDO::SQLSRV_ENCODING_UTF8,
            ],
        ],

        'kasra' => [
            'driver'   => 'sqlsrv',
            'host'     => env('KASRA_HOST', 'KASRA\KASRAPLUS'),
            'port'     => env('KASRA_PORT', ''),
            'database' => env('KASRA_DATABASE', 'framework'),
            'username' => env('KASRA_USERNAME', 'readonly_user'),
            'password' => env('KASRA_PASSWORD', ''),
            'charset'  => 'utf8',
            'prefix'   => '',
            'collation' => 'Persian_100_CI_AI_SC',
            ... (filter_var(env('KASRA_ENCRYPT', false), FILTER_VALIDATE_BOOLEAN) ? [
                'encrypt' => 'yes',
                'trust_server_certificate' => filter_var(env('KASRA_TRUST_SERVER_CERTIFICATE', true), FILTER_VALIDATE_BOOLEAN),
            ] : []),
            'options'  => [
                PDO::SQLSRV_ATTR_QUERY_TIMEOUT => 30,
                PDO::SQLSRV_ATTR_ENCODING => PDO::SQLSRV_ENCODING_UTF8,
            ],
        ],

            'sqlsrv_automation' => [
                'driver' => 'sqlsrv',
                'host' => env('AUTOMATION_DB_HOST', '172.31.5.13\Farzin'),
                'port' => env('AUTOMATION_DB_PORT', '1433'),
                'database' => env('AUTOMATION_DB_DATABASE', 'eOrganization'),
                'username' => env('AUTOMATION_DB_USERNAME', 'app_UserRead'),
                'password' => env('AUTOMATION_DB_PASSWORD', ''),
                'charset' => 'utf8',
                'prefix' => '',
                'collation' => 'Persian_100_CI_AI_SC',
                ... (filter_var(env('AUTOMATION_ENCRYPT', false), FILTER_VALIDATE_BOOLEAN) ? [
                    'encrypt' => 'yes',
                    'trust_server_certificate' => filter_var(env('AUTOMATION_TRUST_SERVER_CERTIFICATE', true), FILTER_VALIDATE_BOOLEAN),
                ] : []),
                'options'  => [
                    PDO::SQLSRV_ATTR_QUERY_TIMEOUT => 30,
                    PDO::SQLSRV_ATTR_ENCODING => PDO::SQLSRV_ENCODING_UTF8,
                ],
            ],

    ],



    'migrations' => 'migrations',

    /*
    |--------------------------------------------------------------------------
    | Redis Databases
    |--------------------------------------------------------------------------
    |
    | Redis is an open source, fast, and advanced key-value store that also
    | provides a richer body of commands than a typical key-value system
    | such as APC or Memcached. Laravel makes it easy to dig right in.
    |
    */

    'redis' => [

        'client' => env('REDIS_CLIENT', 'phpredis'),

        'options' => [
            'cluster' => env('REDIS_CLUSTER', 'redis'),
            'prefix' => env('REDIS_PREFIX', Str::slug(env('APP_NAME', 'laravel'), '_').'_database_'),
        ],

        'default' => [
            'url' => env('REDIS_URL'),
            'host' => env('REDIS_HOST', '127.0.0.1'),
            'username' => env('REDIS_USERNAME'),
            'password' => env('REDIS_PASSWORD'),
            'port' => env('REDIS_PORT', '6379'),
            'database' => env('REDIS_DB', '0'),
        ],

        'cache' => [
            'url' => env('REDIS_URL'),
            'host' => env('REDIS_HOST', '127.0.0.1'),
            'username' => env('REDIS_USERNAME'),
            'password' => env('REDIS_PASSWORD'),
            'port' => env('REDIS_PORT', '6379'),
            'database' => env('REDIS_CACHE_DB', '1'),
        ],

    ],

];
