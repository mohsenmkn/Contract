<?php

return [
    'name' => 'Invoice',
];
