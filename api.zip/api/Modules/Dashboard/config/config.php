<?php

return [
    'name' => 'Dashboard',
];
