<?php

return [
    'name' => 'Guarantee',
];
