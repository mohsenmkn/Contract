<?php

return [
    'name' => 'Acl',
];
