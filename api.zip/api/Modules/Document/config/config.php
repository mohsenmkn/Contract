<?php

return [
    'name' => 'Document',
];
